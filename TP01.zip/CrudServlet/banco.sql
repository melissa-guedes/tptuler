-- ============================================================
-- Script SQL – CRUD Servlet | IFSP Cubatão | CBTSWE1 – ADS 571
-- Execute este script no MySQL antes de rodar o projeto
-- ============================================================

-- 1. Cria o banco de dados (se não existir)
CREATE DATABASE IF NOT EXISTS swii5
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- 2. Seleciona o banco
USE swii5;

-- 3. Cria a tabela user905
CREATE TABLE IF NOT EXISTS user905 (
    id       INT          NOT NULL AUTO_INCREMENT,
    name     VARCHAR(4000),
    password VARCHAR(4000),
    email    VARCHAR(4000),
    country  VARCHAR(4000),
    PRIMARY KEY (id)
);

-- 4. Insere dados de exemplo para popular o banco (print de tela)
INSERT INTO user905 (name, password, email, country) VALUES
    ('João Silva',    'senha123',  'joao@gmail.com',    'Brasil'),
    ('Maria Souza',   'maria456',  'maria@gmail.com',   'Brasil'),
    ('Carlos Mendes', 'carlos789', 'carlos@hotmail.com','Brasil');

-- 5. Confirma os dados inseridos
SELECT * FROM user905;
