# 📋 CRUD Servlet – IFSP Cubatão
**Matéria:** CBTSWE1 – ADS 571  
**Professor:** Wellington Tuler Moraes

---

## ✅ Pré-requisitos

| Software        | Onde baixar                                      |
|-----------------|--------------------------------------------------|
| Java JDK 11+    | https://adoptium.net                             |
| Eclipse IDE EE  | https://www.eclipse.org/downloads/ (Eclipse IDE for Enterprise Java) |
| Apache Tomcat 9 | https://tomcat.apache.org/download-90.cgi        |
| MySQL 8+        | https://dev.mysql.com/downloads/installer/       |
| MySQL Connector/J | https://dev.mysql.com/downloads/connector/j/  |

---

## 🗄️ PASSO 1 – Configurar o Banco de Dados

1. Abra o **MySQL Workbench** ou o terminal MySQL
2. Execute o arquivo `banco.sql` que está nesta pasta:
   ```sql
   SOURCE caminho/para/banco.sql;
   ```
   Ou cole o conteúdo diretamente no Workbench e execute (⚡ ou Ctrl+Shift+Enter)

3. Isso vai criar:
   - Banco de dados: `swii5`
   - Tabela: `user905`
   - 3 registros de exemplo

---

## 🛠️ PASSO 2 – Importar o Projeto no Eclipse

1. Abra o **Eclipse IDE for Enterprise Java**
2. Vá em: **File → Import → General → Existing Projects into Workspace**
3. Clique em **Browse** e selecione a pasta `CrudServlet`
4. Clique em **Finish**

---

## 🔌 PASSO 3 – Adicionar o Driver do MySQL (mysql-connector)

1. Baixe o arquivo `mysql-connector-j-X.X.X.jar` no site da MySQL
2. Dentro do Eclipse, clique com botão direito no projeto → **Properties**
3. Vá em **Java Build Path → Libraries → Add External JARs**
4. Selecione o `.jar` do MySQL Connector
5. Clique em **Apply and Close**
6. **Copie também** o `.jar` para a pasta `WebContent/WEB-INF/lib/` do projeto

---

## 🐱 PASSO 4 – Configurar o Tomcat no Eclipse

1. Vá em: **Window → Preferences → Server → Runtime Environments**
2. Clique em **Add → Apache Tomcat v9.0**
3. Em **Tomcat Installation Directory**, aponte para onde você instalou o Tomcat
4. Clique em **Finish**

Se aparecer a aba **Servers** (parte de baixo do Eclipse):
- Clique com botão direito → **New → Server → Apache Tomcat v9.0**

---

## ⚙️ PASSO 5 – Ajustar Credenciais do Banco (se necessário)

Abra o arquivo `src/EmpDao.java` e edite as linhas:

```java
String dbName     = "swii5?useTimezone=true&serverTimezone=America/Sao_Paulo";
String dbUsername = "root";
String dbPassword = "root"; // ← coloque sua senha do MySQL aqui
```

---

## ▶️ PASSO 6 – Rodar o Projeto

1. Clique com botão direito no projeto no Eclipse
2. Vá em: **Run As → Run on Server**
3. Selecione o **Tomcat 9** e clique em **Finish**
4. O Eclipse vai abrir o navegador interno automaticamente

Acesse também pelo seu navegador:
```
http://localhost:8080/CrudServlet/
```

---

## 📁 Estrutura do Projeto

```
CrudServlet/
├── src/
│   ├── Emp.java           → Model (entidade)
│   ├── EmpDao.java        → DAO (acesso ao banco)
│   ├── SaveServlet.java   → Salvar (Create)
│   ├── ViewServlet.java   → Listar (Read)
│   ├── EditServlet.java   → Formulário de edição
│   ├── EditServlet2.java  → Atualizar (Update)
│   └── DeleteServlet.java → Deletar (Delete)
├── WebContent/
│   ├── index.html         → Página principal / formulário
│   ├── credits.html       → Página de créditos (diferencial)
│   └── WEB-INF/
│       └── web.xml        → Configuração da aplicação
└── banco.sql              → Script para criar banco e tabela
```

---

## ⚠️ Problemas Comuns

| Problema | Solução |
|----------|---------|
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | O .jar do MySQL Connector não foi adicionado ao projeto |
| `Access denied for user 'root'` | Senha do MySQL incorreta em EmpDao.java |
| `Unknown database 'swii5'` | Execute o banco.sql primeiro |
| Porta 8080 ocupada | Vá em Tomcat → Properties → Port e mude para 8081 |
| `404 Not Found` | Verifique se o projeto está deployado no Tomcat corretamente |

---

## 🎓 Funcionalidades Implementadas

- ✅ **Create** – Adicionar novo funcionário (index.html + SaveServlet)
- ✅ **Read** – Listar todos os funcionários (ViewServlet)
- ✅ **Update** – Editar dados (EditServlet + EditServlet2)
- ✅ **Delete** – Excluir com confirmação (DeleteServlet)
- ⭐ **Diferencial** – Página de créditos (credits.html)
