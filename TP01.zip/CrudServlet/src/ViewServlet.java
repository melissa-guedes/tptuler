// Aluno 1: [SEU NOME AQUI]
// Aluno 2: [SEU NOME AQUI]
// Matéria: CBTSWE1 – ADS 571
// Professor: Wellington Tuler Moraes
// IFSP – Campus Cubatão

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'>");
        out.println("<title>Employees List</title>");
        out.println("<style>");
        out.println("body{font-family:Arial,sans-serif;margin:30px;background:#f0f0f0;}");
        out.println("h1{color:#333;}");
        out.println("table{border-collapse:collapse;width:100%;background:white;}");
        out.println("th{background:#4CAF50;color:white;padding:10px;}");
        out.println("td{padding:8px 12px;border:1px solid #ddd;}");
        out.println("tr:nth-child(even){background:#f9f9f9;}");
        out.println("a{color:#1a73e8;text-decoration:none;}");
        out.println("a:hover{text-decoration:underline;}");
        out.println(".btn-delete{color:red;}");
        out.println("</style></head><body>");

        out.println("<a href='index.html'>➕ Add New Employee</a> | <a href='credits.html'>⭐ Créditos</a>");
        out.println("<h1>Employees List</h1>");

        List<Emp> list = EmpDao.getAllEmployees();

        out.print("<table>");
        out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th><th>Edit</th><th>Delete</th></tr>");
        for (Emp e : list) {
            out.print("<tr>");
            out.print("<td>" + e.getId()      + "</td>");
            out.print("<td>" + e.getName()    + "</td>");
            out.print("<td>" + e.getPassword()+ "</td>");
            out.print("<td>" + e.getEmail()   + "</td>");
            out.print("<td>" + e.getCountry() + "</td>");
            out.print("<td><a href='EditServlet?id=" + e.getId() + "'>✏️ edit</a></td>");
            out.print("<td><a class='btn-delete' href='DeleteServlet?id=" + e.getId() + "' onclick=\"return confirm('Deseja excluir?')\">🗑️ delete</a></td>");
            out.print("</tr>");
        }
        out.print("</table>");
        out.println("</body></html>");

        out.close();
    }
}
