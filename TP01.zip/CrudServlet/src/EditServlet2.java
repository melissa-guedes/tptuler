// Aluno 1: [SEU NOME AQUI]
// Aluno 2: [SEU NOME AQUI]
// Matéria: CBTSWE1 – ADS 571
// Professor: Wellington Tuler Moraes
// IFSP – Campus Cubatão

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditServlet2")
public class EditServlet2 extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        String sid      = request.getParameter("id");
        int id          = Integer.parseInt(sid);
        String name     = request.getParameter("name");
        String password = request.getParameter("password");
        String email    = request.getParameter("email");
        String country  = request.getParameter("country");

        Emp e = new Emp();
        e.setId(id);
        e.setName(name);
        e.setPassword(password);
        e.setEmail(email);
        e.setCountry(country);

        int status = EmpDao.update(e);
        if (status > 0) {
            response.sendRedirect("ViewServlet");
        } else {
            out.println("<p style='color:red;'>Sorry! unable to update record</p>");
        }

        out.close();
    }
}
