// Aluno 1: [SEU NOME AQUI]
// Aluno 2: [SEU NOME AQUI]
// Matéria: CBTSWE1 – ADS 571
// Professor: Wellington Tuler Moraes
// IFSP – Campus Cubatão

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        String sid = request.getParameter("id");
        int id = Integer.parseInt(sid);
        Emp e = EmpDao.getEmployeeById(id);

        out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'>");
        out.println("<title>Update Employee</title>");
        out.println("<style>");
        out.println("body{font-family:Arial,sans-serif;margin:30px;background:#f0f0f0;}");
        out.println("h1{color:#333;}");
        out.println("td{padding:6px 10px;}");
        out.println("input[type=text],input[type=password],input[type=email],select{padding:5px;border:1px solid #aaa;border-radius:3px;width:200px;}");
        out.println("input[type=submit]{background:#2196F3;color:white;padding:8px 16px;border:none;border-radius:4px;cursor:pointer;font-size:14px;}");
        out.println("input[type=submit]:hover{background:#1976D2;}");
        out.println("</style></head><body>");

        out.println("<h1>Update Employee</h1>");
        out.print("<form action='EditServlet2' method='post'>");
        out.print("<table>");
        out.print("<tr><td></td><td><input type='hidden' name='id' value='" + e.getId() + "'/></td></tr>");
        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='" + e.getName() + "'/></td></tr>");
        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='" + e.getPassword() + "'/></td></tr>");
        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='" + e.getEmail() + "'/></td></tr>");
        out.print("<tr><td>Country:</td><td>");
        out.print("<select name='country' style='width:150px'>");
        String[] countries = {"India", "USA", "UK", "Brasil", "Other"};
        for (String c : countries) {
            String selected = c.equals(e.getCountry()) ? " selected" : "";
            out.print("<option" + selected + ">" + c + "</option>");
        }
        out.print("</select></td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save'/></td></tr>");
        out.print("</table>");
        out.print("</form>");
        out.println("<br/><a href='ViewServlet'>← Voltar</a>");
        out.println("</body></html>");

        out.close();
    }
}
