
package servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.EmpDao;
import model.Emp;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {

protected void doGet(HttpServletRequest request,
HttpServletResponse response)

throws ServletException, IOException {

response.setContentType("text/html");
PrintWriter out=response.getWriter();

List<Emp> list=EmpDao.getAllEmployees();

out.print("<h1>Employees</h1>");

for(Emp e:list){

out.print(e.getId()+" "+e.getName()+" ");
out.print("<a href='DeleteServlet?id="+e.getId()+"'>Delete</a>");
out.print("<br>");

}

}
}
