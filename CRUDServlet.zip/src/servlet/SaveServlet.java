
package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.EmpDao;
import model.Emp;

@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {

protected void doPost(HttpServletRequest request,
HttpServletResponse response)

throws ServletException, IOException {

String name=request.getParameter("name");
String password=request.getParameter("password");
String email=request.getParameter("email");
String country=request.getParameter("country");

Emp e=new Emp();

e.setName(name);
e.setPassword(password);
e.setEmail(email);
e.setCountry(country);

EmpDao.save(e);

response.sendRedirect("ViewServlet");

}
}
